package com.nbmoody.SpringDataJPAStarter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringDataJpaStarterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringDataJpaStarterApplication.class, args);
	}

}
